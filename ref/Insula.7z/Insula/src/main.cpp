#include "main.h"


void setup(void)
{
	Serial.begin(115200);
	Serial.println("Starting up Green-O-Matic Duemilanove RF Testbed");
	pinMode(13, OUTPUT);

#ifdef RF_TX_PIN
	pinMode(RF_TX_PIN,OUTPUT);
	vw_set_tx_pin(RF_TX_PIN);
    vw_setup(RF_BAUD);
	Serial.print ("RF TX Baud = ");
	Serial.println(RF_BAUD, DEC);
#endif
#ifdef RF_RX_PIN
	pinMode(RF_RX_PIN,INPUT);
	vw_set_rx_pin(RF_RX_PIN);
    vw_setup(RF_BAUD);
    vw_rx_start  ();
	Serial.print ("RF RX Baud = ");
	Serial.println(RF_BAUD, DEC);
#endif
}


int main(void)
{
	init();
	setup();


    /// loop
	for (unsigned long int frame=0;;frame++)
	{
		digitalWrite(13, HIGH);

	    String new_msg = "Loop #";
	    new_msg.concat(frame);
	    Serial.print(new_msg);

#ifdef RF_TX_PIN
	    const char *msg = "TRANSMIT DAMNIT";
	    vw_send((uint8_t *)msg, strlen(msg));
	    vw_wait_tx();
#endif


#ifdef RF_RX_PIN
	    // check RF
		uint8_t  buff_rf      [VW_MAX_MESSAGE_LEN];
		uint8_t  len_rf   =    VW_MAX_MESSAGE_LEN;
		if(vw_get_message(buff_rf, &len_rf))
		{
			Serial.print("RF: ");
			for(uint8_t i = 0; i < len_rf; i++)
				Serial.print(buff_rf[i]);
			Serial.println();
		}
#endif

		digitalWrite(13, LOW);
		delay (25);
	};

	return 0;
}
