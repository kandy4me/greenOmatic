/*
 * main.h
 *
 *  Created on: Feb 22, 2014
 *      Author: jeff
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "arduino/Arduino.h"
#include "arduino/VirtualWire.h"


//// TUNING PARAMETERS
#define LOOP_DELAY 3000 //ms


/// RF
#define RF_BAUD       2400
#define RF_TX_PIN	13


//// Function Definitions
int 	main	(void);
void 	setup	(void);


#endif /* MAIN_H_ */
