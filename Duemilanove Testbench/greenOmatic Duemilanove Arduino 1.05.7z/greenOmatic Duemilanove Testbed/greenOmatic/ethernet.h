#ifndef ethernet_h
#define ethernet_h

#include "../arduino/IPAddress.h"

// Configuration-dependant inclusions
//#include "ENC28J60.h"
#include "Ethernet_Shield.h"


#endif
