/*
 * plant.cpp
 *
 *  Created on: Feb 23, 2014
 *      Author: jeff
 */

#include "plant.h"

plant::plant() {
	// TODO Auto-generated constructor stub

}

plant::~plant() {
	// TODO Auto-generated destructor stub
}

