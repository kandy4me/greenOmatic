/*
 * sensor.cpp
 *
 *  Created on: 2013-02-13
 *      Author: Jeff
 */

#include "sensor.h"


sensor::sensor() {
	// TODO Auto-generated constructor stub

}

sensor::~sensor() {
	// TODO Auto-generated destructor stub
}

