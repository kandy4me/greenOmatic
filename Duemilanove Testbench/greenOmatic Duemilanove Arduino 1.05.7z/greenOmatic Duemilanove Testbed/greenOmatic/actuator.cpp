/*
 * actuator.cpp
 *
 *  Created on: 2013-02-23
 *      Author: Jeff
 */

#include "actuator.h"

actuator::actuator() {
	// TODO Auto-generated constructor stub

}

actuator::~actuator() {
	// TODO Auto-generated destructor stub
}

